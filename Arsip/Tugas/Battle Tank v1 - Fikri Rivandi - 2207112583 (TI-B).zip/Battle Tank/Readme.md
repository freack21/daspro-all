Battle Tank
Fikri Rivandi

Sebuah game Teka-Teki, dimana user ditugaskan untuk menebak titik koordinat posisi Tank.
Pesawat tempur akan menyerang posisi koordinat yang ditebak, dan jika benar, maka BOOMM!!

v1.0
- Menggunakan array, function, perulangan, dan percabangan
- Menampilkan animasi serangan
- Me-random posisi tank yang benar (uncompiled code; Line:88)

Wishlist
- Menambah player
- Menambah sistem skor
- Membatasi kesempatan menjawab